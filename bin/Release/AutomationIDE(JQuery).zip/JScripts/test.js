function test() 
{ 
	alert(\'test\'); 
} 
test();